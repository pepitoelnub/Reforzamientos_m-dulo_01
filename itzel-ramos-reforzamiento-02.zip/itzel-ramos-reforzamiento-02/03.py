var_01 = "3"
var_02 = 4
print(int(var_01) + var_02)
