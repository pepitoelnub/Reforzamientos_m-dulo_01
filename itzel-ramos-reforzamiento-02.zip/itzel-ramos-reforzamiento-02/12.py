lista = ["itzel", "ramos", 4, -10, 13.2, "hola", True, False, 4]
lista_02 = [4, 8, 12, 20, 100, 36]
lista_03 = lista + lista_02
print(lista)
print(lista_02)
print(lista_03)
"""
Al sumar las listas, todos 
los elementos se incluyen 
dentro de la 3ra lista y en caso 
los números repetidos, se repiten 
"""