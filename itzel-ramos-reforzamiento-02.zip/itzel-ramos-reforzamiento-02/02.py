var_01 = 34
multiplicación = var_01 * 10 - 10
multiplicación = float(multiplicación)
print(multiplicación)
print(type(multiplicación))

