mi_saludo = "¡Hi Itzel Ramos!"
mi_nombre_completo = "Itzel Haciel Ramos Gonzales"
print(mi_saludo)
