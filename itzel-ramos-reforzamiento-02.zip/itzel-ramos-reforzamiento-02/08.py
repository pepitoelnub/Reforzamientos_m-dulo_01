lista_01 = []
lista_02 = [4,6,9]

if not lista_01:
    print("lista_01 vacía")
else:
    print("lista_01 llena")
if not lista_02:
    print("lista_02 vacía")
else:
    print("lista_02 llena")

