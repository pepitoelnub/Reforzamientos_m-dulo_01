uno = 40
dos = -10
tres = 35

mod_01 = uno % 3
mod_02 = dos % 5
mod_03 = tres % 7

suma = mod_01 + mod_02 + mod_03
print(suma)
