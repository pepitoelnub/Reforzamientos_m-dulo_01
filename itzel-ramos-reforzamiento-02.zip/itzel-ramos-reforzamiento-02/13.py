lista_01 = ["lenguaje", "cálculo 1", "cálculo 2", "matemática aplicada", "biología", "fundamentos de estadística"]
print(lista_01)
lista_01.extend(["inglés", "botánica", "zoología", "genética"])
print(lista_01)