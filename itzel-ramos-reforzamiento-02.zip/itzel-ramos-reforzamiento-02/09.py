var_01 = 6
operación_01 = 3 ** var_01
operación_02 = operación_01 - (operación_01 * 2)
print(operación_02)