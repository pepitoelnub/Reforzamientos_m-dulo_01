nombre = "Itzel"
carrera = "Genética y Biotecnología"
edad = 17
año_nacimiento = 2007

diccionario = {"nombre": nombre, "carrera": carrera, "edad": edad,"año de nacimiento": año_nacimiento}
print(diccionario)
