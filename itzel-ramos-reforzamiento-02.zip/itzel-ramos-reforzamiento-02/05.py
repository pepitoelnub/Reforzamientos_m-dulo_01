sueldo = int(input("Mi sueldo es: "))
if sueldo % 2 == 0:
    print("El sueldo es par")
else:
    print("El sueldo es impar")

