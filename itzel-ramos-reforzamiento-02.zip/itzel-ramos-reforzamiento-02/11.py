edad = 17
operación = (edad ** 5) / 10
print(type(operación))
módulo = operación % 3
print("el módulo con 3 es: ", módulo)
