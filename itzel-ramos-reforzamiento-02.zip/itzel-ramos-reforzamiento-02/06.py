dat_01 = 13.4
dat_02 = 12.3
dat_03 = 14.6
dat_04 = 6.2
dat_05 = 9.1
media = (dat_01 + dat_02 + dat_03 + dat_04 + dat_05) / 5
print("El media es:", media)
print(type(media))
