""""
Crea dos listas (una de datos string y la otra de datos numéricos) para luego
usar los métodos de orden (los elementos tienen que estar desordenados),
mostrar las listas antes y después de aplicarle los métodos de orden
"""
#Creación de listas
Lista_str = ["Queso", "Pollo", "Leche", "Avena"]
lista_num = [7, 4.1, 2, 4.01]
#Ordenando las listas
lista_num.sort()
Lista_str.sort()
print("La lista de strings erdenada es: ", Lista_str)
print("La lista de números ordenada es: ", lista_num)