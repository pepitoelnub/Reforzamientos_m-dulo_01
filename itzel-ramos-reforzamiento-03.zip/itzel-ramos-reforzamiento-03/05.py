""""
Crear una lista (entre floats y bools, 6 elementos mínimo) donde imprimas el
penúltimo y antepenúltimo valor (por índice). Reconocer cada uno de los tipos
de datos en esta lista creada y mostrar los resultados en consola
"""
#Creación de lista
Lista_nueva = [4.3, "Hola", 90, "Policía", 2, "Itzel"]
print("El penúltimo elemento de mi lista es: ", Lista_nueva[4])
print("El antepenúltimo elemento de mi lista es: ", Lista_nueva[3])