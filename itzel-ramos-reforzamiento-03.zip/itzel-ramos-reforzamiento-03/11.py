# Crear una lista vacía para almacenar compañías de TI
companias_ti = ["Microsoft", "Google", "Apple", "IBM", "Amazon"]

#Lista inversa
lista_inversa = companias_ti.copy()
lista_inversa.reverse()

#muestra las listas
print("\nLista inversa:", lista_inversa)
print("la lista original es: ", companias_ti)



