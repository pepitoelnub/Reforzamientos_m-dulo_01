"""
Elimina ahora todos los elementos de la lista creada previamente y mostrar en
consola la lista actualizada agregando tu nombre, apellido paterno, apellido
materno y edad
"""
Lista_nueva = [4.3, "Hola", 90, "Policía", 2, "Itzel"]
#Elimino los elementos
Lista_nueva.clear()
#Agrego los nuevos elementos
Lista_nueva.append("Itzel")
Lista_nueva.append("Ramos")
Lista_nueva.append("Gonzales")
Lista_nueva.append(17)
print("Mi 'Lista_nueva' actualizada es: ", Lista_nueva)